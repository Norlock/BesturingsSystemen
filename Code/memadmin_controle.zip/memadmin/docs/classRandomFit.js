var classRandomFit =
[
    [ "RandomFit", "classRandomFit.html#a7aa530b1bd96e678f00651890ad856af", null ],
    [ "alloc", "classRandomFit.html#af52a4e6135df83a4df8545c2a46d5463", null ],
    [ "free", "classRandomFit.html#a07d867f6bb58a1e452078649cace7e00", null ],
    [ "getSize", "classRandomFit.html#a1c67381777b1b43a4f237f9045b875cf", null ],
    [ "getType", "classRandomFit.html#aab1d481ff3438ee226e09e20da8130b7", null ],
    [ "report", "classRandomFit.html#a07c0f5a873bcf651d54a4ab5acaa2905", null ],
    [ "setCheck", "classRandomFit.html#a3bf70e649198f0cf39c54c7c55078681", null ],
    [ "setSize", "classRandomFit.html#a81e235b5b9c804a1f6836fa85018611b", null ],
    [ "cflag", "classRandomFit.html#a9d5d07af8e2e54deb7a8863f629fb1d8", null ],
    [ "size", "classRandomFit.html#a5d7a71270a7820aa97ebd17794ce8771", null ],
    [ "type", "classRandomFit.html#a8c31faaa57658964ac597567b10c9983", null ]
];