var annotated =
[
    [ "Allocator", "classAllocator.html", "classAllocator" ],
    [ "Application", "classApplication.html", "classApplication" ],
    [ "Area", "classArea.html", "classArea" ],
    [ "assert_error", "classassert__error.html", "classassert__error" ],
    [ "FirstFit", "classFirstFit.html", "classFirstFit" ],
    [ "FirstFit2", "classFirstFit2.html", "classFirstFit2" ],
    [ "Fitter", "classFitter.html", "classFitter" ],
    [ "NextFit", "classNextFit.html", "classNextFit" ],
    [ "NextFit2", "classNextFit2.html", "classNextFit2" ],
    [ "RandomFit", "classRandomFit.html", "classRandomFit" ],
    [ "Stopwatch", "classStopwatch.html", "classStopwatch" ],
    [ "unix_error", "classunix__error.html", "classunix__error" ]
];