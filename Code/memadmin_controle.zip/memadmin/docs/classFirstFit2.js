var classFirstFit2 =
[
    [ "FirstFit2", "classFirstFit2.html#a6c9ba5a4ef741a48bc7cbac0728fa43d", null ],
    [ "alloc", "classFirstFit2.html#a8fcf584bc8b53b0b10b7bcf117e81dbf", null ],
    [ "dump", "classFirstFit2.html#ab9c5e0f3aaafd2e891e8bc31df936a74", null ],
    [ "free", "classFirstFit2.html#a6bddceff61dc29e56eed7243b27b99f0", null ],
    [ "getSize", "classFirstFit2.html#a1c67381777b1b43a4f237f9045b875cf", null ],
    [ "getType", "classFirstFit2.html#aab1d481ff3438ee226e09e20da8130b7", null ],
    [ "reclaim", "classFirstFit2.html#aecb473b74da2969d4efa47ecdf1a21fd", null ],
    [ "report", "classFirstFit2.html#ae9cc31ac2ac3c6e3a0043f8ee77de937", null ],
    [ "searcher", "classFirstFit2.html#af90d381c1fee86cbe4c3f559e12314a5", null ],
    [ "setCheck", "classFirstFit2.html#a3bf70e649198f0cf39c54c7c55078681", null ],
    [ "setSize", "classFirstFit2.html#a713558e9a318d4ee6276322c02de2aac", null ],
    [ "updateStats", "classFirstFit2.html#a3d66889cb66a16c24d4cca8d0b72806b", null ],
    [ "areas", "classFirstFit2.html#a3a69186e743ad105358ad13f67c99004", null ],
    [ "cflag", "classFirstFit2.html#a9d5d07af8e2e54deb7a8863f629fb1d8", null ],
    [ "mergers", "classFirstFit2.html#a151741292950ebd171ea81f1953e118a", null ],
    [ "qcnt", "classFirstFit2.html#a31dd0a74283e3a6b182a7940ae654c11", null ],
    [ "qsum", "classFirstFit2.html#a5a632aab749445ef4f366e2ebac01e85", null ],
    [ "qsum2", "classFirstFit2.html#a47fbb29535d6b46c8bbbd4db243d2579", null ],
    [ "reclaims", "classFirstFit2.html#a9377ebc83e806d89983d5507005f7913", null ],
    [ "size", "classFirstFit2.html#a5d7a71270a7820aa97ebd17794ce8771", null ],
    [ "type", "classFirstFit2.html#a8c31faaa57658964ac597567b10c9983", null ]
];