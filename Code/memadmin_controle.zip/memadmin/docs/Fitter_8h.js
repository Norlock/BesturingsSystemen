var Fitter_8h =
[
    [ "Fitter", "classFitter.html", "classFitter" ],
    [ "ALiterator", "Fitter_8h.html#a1f08847e3548b0d3f145e2bb9f643e36", null ],
    [ "AreaList", "Fitter_8h.html#a7a35f1aa1605fef664932561b0ab4142", null ]
];