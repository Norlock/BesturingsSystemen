var common_8h =
[
    [ "__DEVCPP__", "common_8h.html#aa0cebd87bfb2bf6c8ba8b904f9c525db", null ],
    [ "__ECLIPSE__", "common_8h.html#a650eeaca5114996dd271418fc820ca3a", null ]
];