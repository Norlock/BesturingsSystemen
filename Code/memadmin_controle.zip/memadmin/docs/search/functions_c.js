var searchData=
[
  ['unix_5ferror',['unix_error',['../classunix__error.html#aa4b2cc489b5b8f0ee5eb41869b473c89',1,'unix_error::unix_error(const std::string &amp;what)'],['../classunix__error.html#af137acb46bd7e4b7f9471ecec8131f60',1,'unix_error::unix_error(const char *what)'],['../classunix__error.html#a4fcf8a71756c1b024625aa82165de3f4',1,'unix_error::unix_error(const char *where, const char *what)'],['../classunix__error.html#acf795d52869878610f4a11ae0b34c0a9',1,'unix_error::unix_error(const char *where, const char *func, const char *what)'],['../classunix__error.html#a190bec10c7dc138c1c5e14509b0b021e',1,'unix_error::unix_error(const char *where, const char *func, const std::string &amp;what)']]],
  ['updatestats',['updateStats',['../classFirstFit.html#a3d66889cb66a16c24d4cca8d0b72806b',1,'FirstFit::updateStats()'],['../classNextFit.html#a37f2274a6f4517e5a5b8e034e9f783fc',1,'NextFit::updateStats()']]]
];
