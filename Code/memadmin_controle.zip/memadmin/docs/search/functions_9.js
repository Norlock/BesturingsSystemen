var searchData=
[
  ['randomfit',['RandomFit',['../classRandomFit.html#a7aa530b1bd96e678f00651890ad856af',1,'RandomFit']]],
  ['randomscenario',['randomscenario',['../classApplication.html#a559eacd1ed11e4ce97f12a1d0e902c61',1,'Application']]],
  ['reclaim',['reclaim',['../classFirstFit.html#aecb473b74da2969d4efa47ecdf1a21fd',1,'FirstFit::reclaim()'],['../classFitter.html#ac8ffb3a3e66ff4a6f074106f16014235',1,'Fitter::reclaim()'],['../classNextFit.html#a85df8208e65d8ec760fd0277fdf7724f',1,'NextFit::reclaim()']]],
  ['report',['report',['../classAllocator.html#a4eacb09e54fdd0fa6e6d70a0dced08ba',1,'Allocator::report()'],['../classFitter.html#ae9cc31ac2ac3c6e3a0043f8ee77de937',1,'Fitter::report()'],['../classRandomFit.html#a07c0f5a873bcf651d54a4ab5acaa2905',1,'RandomFit::report()'],['../classStopwatch.html#aa5977fc4a8ede47878790ff6d2cf569d',1,'Stopwatch::report()']]],
  ['reset',['reset',['../classStopwatch.html#a42c7014e7fffcf4c56ca6fb07f8eb31c',1,'Stopwatch']]]
];
