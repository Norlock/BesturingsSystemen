var searchData=
[
  ['nextfit',['NextFit',['../classNextFit.html',1,'']]],
  ['nextfit2',['NextFit2',['../classNextFit2.html',1,'']]]
];
