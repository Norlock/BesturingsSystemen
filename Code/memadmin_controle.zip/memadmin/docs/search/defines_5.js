var searchData=
[
  ['s_5fclock',['S_CLOCK',['../Stopwatch_8h.html#a11aee89e57ce75fd2084050f5f705757',1,'Stopwatch.h']]],
  ['s_5fgpt32',['S_GPT32',['../Stopwatch_8h.html#a4b3ae370cd0cb27c4f2e90dc5e1276b1',1,'Stopwatch.h']]],
  ['s_5frusage',['S_RUSAGE',['../Stopwatch_8h.html#a942fd2dbc3d2ae375282fbaaa78ee31f',1,'Stopwatch.h']]],
  ['s_5ftime',['S_TIME',['../Stopwatch_8h.html#aa092233cbf5fdea76c7eb400de0522e3',1,'Stopwatch.h']]],
  ['s_5ftimes',['S_TIMES',['../Stopwatch_8h.html#aaac8b08f06dfc11b5badfb15105eeb84',1,'Stopwatch.h']]]
];
