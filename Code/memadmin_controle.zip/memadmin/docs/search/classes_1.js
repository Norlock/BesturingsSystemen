var searchData=
[
  ['firstfit',['FirstFit',['../classFirstFit.html',1,'']]],
  ['firstfit2',['FirstFit2',['../classFirstFit2.html',1,'']]],
  ['fitter',['Fitter',['../classFitter.html',1,'']]]
];
