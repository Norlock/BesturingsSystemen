var searchData=
[
  ['nextfit',['NextFit',['../classNextFit.html',1,'NextFit'],['../classNextFit.html#a51b5c8268b01baaae047c1582865b961',1,'NextFit::NextFit()']]],
  ['nextfit_2ecc',['NextFit.cc',['../NextFit_8cc.html',1,'']]],
  ['nextfit_2eh',['NextFit.h',['../NextFit_8h.html',1,'']]],
  ['nextfit2',['NextFit2',['../classNextFit2.html',1,'NextFit2'],['../classNextFit2.html#ad91161d338cc9a9d4f4222f37fef6e4a',1,'NextFit2::NextFit2()']]],
  ['nextfit2_2ecc',['NextFit2.cc',['../NextFit2_8cc.html',1,'']]],
  ['nextfit2_2eh',['NextFit2.h',['../NextFit2_8h.html',1,'']]],
  ['notreached',['notreached',['../asserts_8h.html#a34068d01a5fd8b0d476321af113ff221',1,'asserts.h']]]
];
