var searchData=
[
  ['code',['code',['../classunix__error.html#a9d7221622930d3b4e00085afaafa4b78',1,'unix_error']]]
];
