var searchData=
[
  ['join',['join',['../classArea.html#a09628d6fefec11182922506da990a1ae',1,'Area']]]
];
