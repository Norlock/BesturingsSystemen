var searchData=
[
  ['alloc',['alloc',['../classAllocator.html#a4efd7fec6488aa0e91866715e1ebe53b',1,'Allocator::alloc()'],['../classFirstFit.html#a8fcf584bc8b53b0b10b7bcf117e81dbf',1,'FirstFit::alloc()'],['../classNextFit.html#ada8ac382ce2331ae281c01059100e8c3',1,'NextFit::alloc()'],['../classRandomFit.html#af52a4e6135df83a4df8545c2a46d5463',1,'RandomFit::alloc()']]],
  ['allocator',['Allocator',['../classAllocator.html#a1598441d389459785df9582f3ce3551e',1,'Allocator']]],
  ['application',['Application',['../classApplication.html#a3af4f93c915f9c4e35e192513f0cf64c',1,'Application']]],
  ['area',['Area',['../classArea.html#a18d88076b96b8447af329953c82f85b9',1,'Area']]],
  ['assert_5ferror',['assert_error',['../classassert__error.html#a98f377c2625720b03960173712e96c2e',1,'assert_error::assert_error(const std::string &amp;what_arg)'],['../classassert__error.html#acf0cf118a9be9333af53e964e5fdbeba',1,'assert_error::assert_error(const char *what_arg)'],['../classassert__error.html#afc5384532d3b496213f69b0c601d9813',1,'assert_error::assert_error(const char *where, const char *func, const char *what)']]]
];
