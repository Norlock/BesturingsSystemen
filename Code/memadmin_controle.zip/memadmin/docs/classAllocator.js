var classAllocator =
[
    [ "Allocator", "classAllocator.html#a1598441d389459785df9582f3ce3551e", null ],
    [ "alloc", "classAllocator.html#a4efd7fec6488aa0e91866715e1ebe53b", null ],
    [ "free", "classAllocator.html#aaab40dae6e0206c757c5f5bbff01d54d", null ],
    [ "getSize", "classAllocator.html#a1c67381777b1b43a4f237f9045b875cf", null ],
    [ "getType", "classAllocator.html#aab1d481ff3438ee226e09e20da8130b7", null ],
    [ "report", "classAllocator.html#a4eacb09e54fdd0fa6e6d70a0dced08ba", null ],
    [ "setCheck", "classAllocator.html#a3bf70e649198f0cf39c54c7c55078681", null ],
    [ "setSize", "classAllocator.html#a81e235b5b9c804a1f6836fa85018611b", null ],
    [ "cflag", "classAllocator.html#a9d5d07af8e2e54deb7a8863f629fb1d8", null ],
    [ "size", "classAllocator.html#a5d7a71270a7820aa97ebd17794ce8771", null ],
    [ "type", "classAllocator.html#a8c31faaa57658964ac597567b10c9983", null ]
];